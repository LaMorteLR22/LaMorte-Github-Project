var img;
var img2;
var img3;
function preload(){
  img = loadImage("metapod.png");
  img2 = loadImage("cursola.png");
  img3 = loadImage("shuckle.png");
}
function setup() {
  createCanvas(400, 400);
  textFont("Source Code Pro");
  stroke(110);
  fill(0);
  textSize(30)
}
function draw() {
  background(220);
  image(img,0,0,mouseX*2,mouseY*2);
  image(img2,200,200);
  image(img3,0,0);
  image(img3,0,mouseY-1);
  text("I'm typing on the screen.",50,50,300,200);
}