//I don't have a webcam on my computer, sorry! I still wrote the code for it though, so hopefully it works.
var sine;
var freq = 400;
var capture;
function preload() {
  funnysound = loadSound("bruh.mp3");
}
function setup() {
  createCanvas(440, 440);
  sine = new p5.SinOsc();
  sine.start();
  capture = createCapture();
  capture.hide();
}

function draw() {
  background(0);
  funnysound.play();
  var aspectRatio = capture.height/capture.width;
  var he = width * aspectRatio;
  var hertz = map(mouseX, 0, width, 20.0, 440.0);
  image(capture, 0, 0, width, he);
  filter(OPAQUE);
  sine.freq(hertz);
  stroke(204);
  for (var x = 0; x < width; x++) {
    var angle = map(x, 0, width, 0, TWO_PI * hertz);
    var sinValue = sin(angle) * 120;
    line(x, 0, x, height/2 + sinValue);
  }
}
